package tests;

import calculator.model.Calculator;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class TestCalculator {

    @Test
    public void testDivideCalculator() {
        Calculator calculator = new Calculator();
//        assertTrue(true);
        assertEquals(0.0, calculator.displayNumber(), 0.001);
        calculator.numberPressed(2);
        assertEquals(2, calculator.displayNumber(), 0.001);
        calculator.numberPressed(5);
        assertEquals(25.0, calculator.displayNumber(), 0.001);
        calculator.dividePressed();
        calculator.numberPressed(5);
        calculator.equalsPressed();
        assertEquals(5.0, calculator.displayNumber(), 0.001);

    }
    @Test
    public void testMultiply(){
        Calculator calculator1 = new Calculator();
//        assertTrue(true);
        assertEquals(0.0, calculator1.displayNumber(), 0.001);
        calculator1.numberPressed(1);
        calculator1.numberPressed(2);
        assertEquals(12.0, calculator1.displayNumber(), 0.001);
        calculator1.multiplyPressed();
        calculator1.numberPressed(3);
        calculator1.equalsPressed();
        assertEquals(36.0, calculator1.displayNumber(), 0.001);
    }
    @Test
    public void testAdd(){
        Calculator calculator2 = new Calculator();
//        assertTrue(true);
        assertEquals(0.0, calculator2.displayNumber(), 0.001);
        calculator2.numberPressed(1);
        calculator2.numberPressed(2);
        assertEquals(12.0, calculator2.displayNumber(), 0.001);
        calculator2.addPressed();
        calculator2.numberPressed(3);
        calculator2.equalsPressed();
        assertEquals(15.0, calculator2.displayNumber(), 0.001);
    }
    @Test
    public void testSubtract(){
        Calculator calculator3 = new Calculator();
        assertEquals(0.0, calculator3.displayNumber(), 0.001);
        calculator3.numberPressed(1);
        calculator3.numberPressed(2);
        assertEquals(12.0, calculator3.displayNumber(), 0.001);
        calculator3.subtractPressed();
        calculator3.numberPressed(3);
        calculator3.equalsPressed();
    }
    @Test
    public void testSecondOperator(){
        Calculator calculator3 = new Calculator();
//        assertTrue(true);
        assertEquals(0.0, calculator3.displayNumber(), 0.001);
        calculator3.numberPressed(1);
        calculator3.numberPressed(2);
        assertEquals(12.0, calculator3.displayNumber(), 0.001);
        calculator3.subtractPressed();
        calculator3.numberPressed(3);
        calculator3.equalsPressed();
        assertEquals(9.0, calculator3.displayNumber(), 0.001);
        calculator3.dividePressed();
        calculator3.numberPressed(3);
        calculator3.equalsPressed();
        assertEquals(3.0, calculator3.displayNumber(), 0.001);
    }
    @Test
    public void testRHS(){
//        System.out.println(.5*12.);
        Calculator calculator3 = new Calculator();
//        assertTrue(true);
        assertEquals(0.0, calculator3.displayNumber(), 0.001);
        calculator3.numberPressed(2);
        calculator3.numberPressed(0);
//        calculator3.numberPressed(3);
        assertEquals(20.0, calculator3.displayNumber(), 0.001);
        calculator3.addPressed();
        calculator3.numberPressed(1);
        calculator3.numberPressed(5);
        calculator3.equalsPressed();
        assertEquals(35.0, calculator3.displayNumber(), 0.001);
        calculator3.dividePressed();
        calculator3.numberPressed(1);
        calculator3.numberPressed(0);
        calculator3.equalsPressed();
        assertEquals(3.5, calculator3.displayNumber(), 0.001);
    }
    @Test
    public void testMulitple(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(3);
        calculator.addPressed();
        calculator.numberPressed(4);
        calculator.equalsPressed();
        calculator.multiplyPressed();
        calculator.numberPressed(2);
        calculator.equalsPressed();
        assertEquals(14.0, calculator.displayNumber(), 0.001);
    }
    @Test
    public void testClear(){
        Calculator calculator3 = new Calculator();
//        assertTrue(true);
        calculator3.numberPressed(1);
        calculator3.numberPressed(2);
        calculator3.clearPressed();
        assertEquals(0.0, calculator3.displayNumber(), 0.001);
    }
    @Test
    public void testDecimal(){
        Calculator calculator = new Calculator();
        assertEquals(0.0, calculator.displayNumber(), 0.001);
        calculator.decimalPressed();
        calculator.numberPressed(5);
        calculator.multiplyPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(2);
        calculator.equalsPressed();
        assertEquals(6.0, calculator.displayNumber(), 0.001);
    }
    @Test
    public void testDecimalFirst(){
        Calculator calculator = new Calculator();
        assertEquals(0.0, calculator.displayNumber(), 0.001);
        calculator.decimalPressed();
        calculator.numberPressed(5);
        assertEquals(0.5, calculator.displayNumber(), 0.001);
    }
    @Test
    public void testMultipleDecimal(){
        Calculator calculator = new Calculator();
        assertEquals(0.0, calculator.displayNumber(), 0.001);
        calculator.numberPressed(1);
        calculator.numberPressed(2);
        calculator.decimalPressed();
        calculator.numberPressed(5);
        calculator.decimalPressed();
        calculator.decimalPressed();
        calculator.numberPressed(0);
        calculator.decimalPressed();
        calculator.numberPressed(5);
        assertEquals(12.505, calculator.displayNumber(), 0.001);
        calculator.subtractPressed();
        calculator.numberPressed(2);
        calculator.decimalPressed();
        calculator.numberPressed(5);
        calculator.equalsPressed();
        assertEquals(10.005, calculator.displayNumber(), 0.001);
    }
    @Test
    public void testMultipleEqual(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(8);
        calculator.numberPressed(0);
        calculator.subtractPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(0);
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(40.0, calculator.displayNumber(), 0.001);


    }

}
