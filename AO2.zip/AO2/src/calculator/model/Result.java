package calculator.model;

public class Result implements State{
    protected final Calculator calculator;
    public Result(Calculator calculator){
        this.calculator=calculator;
    }
    @Override
    public double displayNumber(){
        return this.calculator.getResultNumber();
//        return this.calculator.getFirstNumber()/this.calculator.getSecondNumber();
//        String operator = this.calculator.getOperator();
//        String divide = "/";
//        String multiply = "*";
//        String add = "+";
//        String subtract = "-";
//        if (operator.equals(divide)){
//            System.out.println(this.calculator.getFirstNumber()/this.calculator.getSecondNumber());
//            return this.calculator.getFirstNumber()/this.calculator.getSecondNumber();
//        }else if(operator.equals(multiply)){
//            return this.calculator.getFirstNumber()*this.calculator.getSecondNumber();
//        }else if (operator.equals(add)){
//            return this.calculator.getFirstNumber()+this.calculator.getSecondNumber();
//        }else{
//            System.out.println(this.calculator.getFirstNumber()-this.calculator.getSecondNumber());
//            return this.calculator.getFirstNumber()-this.calculator.getSecondNumber();
//        }


    }
    @Override
    public void clearPressed(){
        this.calculator.setFirstNumber(0.0);
        this.calculator.setState(new FirstNumber(this.calculator));
    }
    @Override
    public void numberPressed(int number){

    }
    @Override
    public void dividePressed(){
        System.out.println(this.calculator.displayNumber());
        this.calculator.setFirstNumber(this.calculator.displayNumber());
//        this.calculator.setOperator("/");
        this.calculator.setState(new Divide(this.calculator));
    }
    @Override
    public void multiplyPressed(){
//        this.calculator.setOperator("*");
        this.calculator.setFirstNumber(displayNumber());
        this.calculator.setState(new Multiply(this.calculator));

    }
    @Override
    public void subtractPressed(){
//        this.calculator.setOperator("-");
        this.calculator.setFirstNumber(displayNumber());
        this.calculator.setState(new Subtract(this.calculator));

    }
    @Override
    public void addPressed(){
//        this.calculator.setOperator("+");
        this.calculator.setFirstNumber(displayNumber());
        this.calculator.setState(new Add(this.calculator));

    }
    @Override
    public void equalsPressed(){
        this.calculator.setFirstNumber(displayNumber());
//        this.calculator.setSecondNumber();
        this.calculator.getOperator().equalsPressed();

    }
    @Override
    public void decimalPressed(){

    }
}
