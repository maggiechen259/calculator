package calculator.model;

public class Operator implements State{
    private Calculator calculator;
    public Operator(Calculator calculator){
        this.calculator = calculator;
    }
    @Override
    public double displayNumber(){
        return 0.0;
    }
    @Override
    public void clearPressed(){
        this.calculator.setState(new Initial(this.calculator));
    }
    @Override
    public void numberPressed(int number){
        this.calculator.setState(new SecondNumber(this.calculator));
    }
    @Override
    public void dividePressed(){
    }
    @Override
    public void multiplyPressed(){
    }
    @Override
    public void subtractPressed(){
    }
    @Override
    public void addPressed(){
    }
    @Override
    public void equalsPressed(){
    }
    @Override
    public void decimalPressed(){
    }
}
