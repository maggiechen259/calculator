package calculator.model;

public class Divide implements State{
    protected final Calculator calculator;
    private String numberAsString = "";
    public Divide(Calculator calculator){
        this.calculator = calculator;
    }
    @Override
    public double displayNumber(){
        return 0.0;

    }

    @Override
    public void clearPressed(){
        this.calculator.setFirstNumber(0.0);
        this.calculator.setState(new FirstNumber(this.calculator));
    }
    @Override
    public void numberPressed(int number){
        numberAsString+=number;
        this.calculator.setSecondNumber(Double.parseDouble(numberAsString));
    }
    @Override
    public void dividePressed(){
    }
    @Override
    public void multiplyPressed(){

    }
    @Override
    public void subtractPressed(){

    }
    @Override
    public void addPressed(){

    }
    @Override
    public void equalsPressed(){
        this.calculator.setOperator(new Divide(this.calculator));
        this.calculator.setResultNumber(this.calculator.getFirstNumber()/this.calculator.getSecondNumber());
        this.calculator.setState(new Result(this.calculator));
    }
    @Override
    public void decimalPressed(){
        numberAsString+=".";
        this.calculator.setSecondNumberdecimal(numberAsString);
        this.calculator.setState(new DivideSecondDecimal(this.calculator));

    }
}
