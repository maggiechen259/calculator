package calculator.model;

public class Calculator {
    private State state = new FirstNumber(this);
    private State operator = new Add(this);
    private String firstNumberdecimal = "";
    private String secondNumberdecimal = "";
    private double firstNumber = 0.0;
    private double secondNumber = 0.0;
    private double resultNumber = 0.0;
    public void setFirstNumberdecimal(String firstNumberdecimal){
        this.firstNumberdecimal = firstNumberdecimal;
    }
    public String getFirstNumberdecimal(){
        return firstNumberdecimal;
    }
    public void setSecondNumberdecimal(String secondNumberdecimal){
        this.secondNumberdecimal = secondNumberdecimal;
    }
    public String getSecondNumberdecimal(){
        return secondNumberdecimal;
    }
    public void setOperator(State operator){
        this.operator = operator;
    }
    public State getOperator(){
        return operator;
    }
    public void setState(State newState){
        this.state = newState;
    }
    public void setResultNumber(Double resultNumber){
        this.resultNumber=resultNumber;
    }
    public Double getResultNumber(){
        return this.resultNumber;
    }
    public void setFirstNumber(double firstNumber){
        this.firstNumber = firstNumber;
    }
    public double getFirstNumber(){
        return this.firstNumber;
    }
    public void setSecondNumber(double secondNumber){
        this.secondNumber = secondNumber;
    }
    public double getSecondNumber(){
        return this.secondNumber;
    }

    public Calculator(){

    }

    // Accessed by View. You should edit this method as you build functionality
    //The calculator initially displays 0.0
    public double displayNumber() {
        // TODO
        return this.state.displayNumber();
    }

    public void clearPressed() {
        // TODO
        this.state.clearPressed();
    }

    public void numberPressed(int number) {
        // TODO
        this.state.numberPressed(number);
    }

    public void dividePressed() {
        // TODO
        this.state.dividePressed();
    }

    public void multiplyPressed() {
        // TODO
        this.state.multiplyPressed();
    }

    public void subtractPressed() {
        // TODO
        this.state.subtractPressed();
    }

    public void addPressed() {
        // TODO
        this.state.addPressed();
    }

    public void equalsPressed() {
        // TODO
        this.state.equalsPressed();
    }

    public void decimalPressed() {
        // TODO
        this.state.decimalPressed();
    }


}
