package calculator.model;

public class SubtractSecondDecimal implements State{
    protected final Calculator calculator;
    private String numberAsString = "";
    public SubtractSecondDecimal(Calculator calculator){
        this.calculator=calculator;
    }
    @Override
    public double displayNumber(){
        return this.calculator.getFirstNumber();

    }
    @Override
    public void clearPressed(){
        this.calculator.setFirstNumber(0.0);
//        this.calculator.setState(new FirstNumber(this.calculator));
    }
    @Override
    public void numberPressed(int number){
        this.calculator.setSecondNumberdecimal(this.calculator.getSecondNumberdecimal()+number);
        this.calculator.setSecondNumber(Double.parseDouble(this.calculator.getSecondNumberdecimal()));
    }
    @Override
    public void dividePressed(){
//        this.calculator.setOperator("/");
        this.calculator.setState(new Divide(this.calculator));
        this.calculator.setState(new Operator(this.calculator));
    }
    @Override
    public void multiplyPressed(){
//        this.calculator.setOperator("*");
        this.calculator.setState(new Multiply(this.calculator));
        this.calculator.setState(new Operator(this.calculator));
    }
    @Override
    public void subtractPressed(){
//        this.calculator.setOperator("-");
        this.calculator.setState(new Subtract(this.calculator));
        this.calculator.setState(new Operator(this.calculator));

    }
    @Override
    public void addPressed(){
//        this.calculator.setOperator("+");
        this.calculator.setState(new Add(this.calculator));
        this.calculator.setState(new Operator(this.calculator));
    }
    @Override
    public void equalsPressed(){
        this.calculator.setOperator(new Subtract(this.calculator));
        this.calculator.setResultNumber(this.calculator.getFirstNumber()-this.calculator.getSecondNumber());
        this.calculator.setState(new Result(this.calculator));
    }
    @Override
    public void decimalPressed(){
//        numberAsString+=".";
//        this.calculator.setFirstNumber(Double.parseDouble(numberAsString));
//        this.calculator.setState(new );

    }
}
