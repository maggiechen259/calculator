package calculator.model;

public class Decimal implements State{
    protected final Calculator calculator;
    private String numberAsString = "";
    public Decimal(Calculator calculator){
        this.calculator=calculator;
    }
    @Override
    public double displayNumber(){
        return this.calculator.getFirstNumber();

    }
    @Override
    public void clearPressed(){
        this.calculator.setFirstNumber(0.0);
//        this.calculator.setState(new FirstNumber(this.calculator));
    }
    @Override
    public void numberPressed(int number){
        this.calculator.setFirstNumberdecimal(this.calculator.getFirstNumberdecimal()+number);
        this.calculator.setFirstNumber(Double.parseDouble(this.calculator.getFirstNumberdecimal()));
    }
    @Override
    public void dividePressed(){
//        this.calculator.setOperator("/");
        this.calculator.setState(new Divide(this.calculator));
//        this.calculator.setState(new Operator(this.calculator));
    }
    @Override
    public void multiplyPressed(){
//        this.calculator.setOperator("*");
        this.calculator.setState(new Multiply(this.calculator));
//        this.calculator.setState(new Operator(this.calculator));
    }
    @Override
    public void subtractPressed(){
//        this.calculator.setOperator("-");
        this.calculator.setState(new Subtract(this.calculator));
        //this.calculator.setState(new Operator(this.calculator));

    }
    @Override
    public void addPressed(){
//        this.calculator.setOperator("+");
        this.calculator.setState(new Add(this.calculator));
        //this.calculator.setState(new Operator(this.calculator));
    }
    @Override
    public void equalsPressed(){
    }
    @Override
    public void decimalPressed(){
//        numberAsString+=".";
//        this.calculator.setFirstNumber(Double.parseDouble(numberAsString));
//        this.calculator.setState(new );

    }
}
