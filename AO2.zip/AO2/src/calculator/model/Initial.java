package calculator.model;

public class Initial implements State{
    private Calculator calculator;
    private String numberAsString = "";
    public Initial(Calculator calculator){
        this.calculator=calculator;
    }
    @Override
    public double displayNumber(){
        return 0.0;

    }
    @Override
    public void clearPressed(){
    }
    @Override
    public void numberPressed(int number){
        numberAsString+=number;
        this.calculator.setFirstNumber(Double.parseDouble(numberAsString));
    }
    @Override
    public void dividePressed(){
    }
    @Override
    public void multiplyPressed(){
    }
    @Override
    public void subtractPressed(){
    }
    @Override
    public void addPressed(){
    }
    @Override
    public void equalsPressed(){
    }
    @Override
    public void decimalPressed(){
    }
}
